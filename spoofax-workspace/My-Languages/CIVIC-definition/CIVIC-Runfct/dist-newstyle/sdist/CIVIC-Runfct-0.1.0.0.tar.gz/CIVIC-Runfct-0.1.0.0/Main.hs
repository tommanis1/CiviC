import Funcons.Tools (mkMainWithLibraryEntitiesTypes)
import Funcons.CIVIC.CIVICFuncons.CIVICFuncons
main = mkMainWithLibraryEntitiesTypes funcons entities types